#define BOOST_TEST_MODULE server tests

#include <boost/test/unit_test.hpp>

/*
 * This file will contain an automatically generated main function.
 */
