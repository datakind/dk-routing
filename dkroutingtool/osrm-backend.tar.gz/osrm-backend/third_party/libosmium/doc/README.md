
The `header.html` is created with:

`doxygen -w html header.html footer.html stylesheet.css`

This might have to be run again for newer Doxygen versions. After that add
changes back in.

