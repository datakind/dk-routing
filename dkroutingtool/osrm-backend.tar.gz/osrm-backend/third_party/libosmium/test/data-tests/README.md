# OSM Testdata

This directory contains software that can be used with the osm-testdata
repository at https://github.com/osmcode/osm-testdata . To use it, clone
the `osm-testdata` repository in the same directory where you cloned the
`libosmium` repository.

Tests will be built if the CMake option `BUILD_DATA_TESTS` is set and run as
part of the `ctest` run.

