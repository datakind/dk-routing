#include <mapbox/geometry.hpp>

void test() {
    mapbox::geometry::geometry_collection<double> gc;
}
