
Tiny and fast vector tile decoder and encoder in C++.

This is the API documentation that was automatically created from the
source code. For more information about vtzero go to
https://github.com/mapbox/vtzero .

Vtzero is a header-only library. You do not need to compile and link it,
just include the headers you need.

Everything in namespaces called "detail" is for internal vtzero use only,
do not depend on it in your code.

